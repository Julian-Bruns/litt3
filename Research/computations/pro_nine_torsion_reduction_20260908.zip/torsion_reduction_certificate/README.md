# Exact certificates for a new reduction of the W3[9] question

## Scope

These files do **not** prove W3(X,O) intersect J[9] = W3(X,O) intersect J[3].
They certify the following two exclusions for the exact polynomial in the question:

1. Every class in W2(X,O) killed by 9 is killed by 3 and has branch-supported degree-two representative. There are 66 such classes.
2. A nonzero order-nine class in W3 cannot have a representative containing two distinct points of one x-fiber.

Together with the supplied W1 result and the structural arguments in the accompanying answer, this leaves only finite, branch-free divisors 2P+Q or P+Q+R, whose distinct support points have distinct x-coordinates. For any remaining solution A+By+Cy^2, both B and C are nonzero.

## Run

From this directory run:

    python verify.py

Only the Python standard library is used. The program checks all polynomial identities and all finite-field assertions used in the two exclusions, then writes detailed JSON certificate data. It does not search an arbitrary collection of small finite fields.

## Field notation

The base field is F_25 = F_5[a]/(a^2-a+2), so a^2=a+3. A coefficient b+c*a is encoded by the integer b+5*c, with 0 <= b,c < 5. For example, 17 denotes 2+3*a. Extension-field elements are coefficient vectors in the basis 1,r,...,r^(d-1) for the displayed, verified irreducible polynomial of degree d.

The symbolic variables in the geometric reduction initially range over the algebraic closure. Finite extension fields are introduced only after their defining polynomial restrictions have been proved. No identity z^5=z is imposed on a variable over the algebraic closure.

## Degree-two completeness reduction

For a finite branch-free divisor E of degree two with div(f)=9E-18O, the pole basis gives f=A+By, deg A=6, deg B<=2. Normalize A to be monic and set R=x^2+r*x+s, also monic. Then

    A^3+B^3*F=R^9,

and A,B,R are pairwise coprime as required by the actual divisor condition. Degree comparison, followed by differentiation, excludes deg B=0,1. For deg B=2, writing T=R^3 gives

    H=A'*R-3*A*R'=B^2*kappa*(x+t),  kappa != 0.

The functions z=A/R^3 and w=By/R^3 map X to z^3+w^3=1. Its differential dz/w^2 is exact in characteristic 5:

    dz/w^2 = d((z+z^4)/w^5).

Its pullback is kappa*R^2*(x+t)*dx/y^2. Exactness forces the coefficients of x^4,x^9,x^14 in F*R^2*(x+t) to vanish. The x^14 coefficient gives t=-F_9-2r.

The other two equations are quadratic in s. verify.py derives them symbolically, checks their quadratic resultant, and checks the linear elimination of s. The result is

    P(r)=(r+2a+3)^2*H2(r)=0,

where

    H2(r)=r^6+4r^5+(2a+2)r^4+4a*r^3+(4a+2)r^2+(a+3)r+(2a+2),

and

    s=2a*r^7-2a*r^6+a*r^5-r^4+2r^3-(2a+2)r^2-2a*r-2a.

Irreducibility of H2 is verified. Thus there are at most seven geometric candidate quadratics R. This includes the possibility of a repeated root of R; nothing in the elimination discards repeated support.

For each factor of P, work in its verified field K. Write F mod R=f0+f1*x; the calculation verifies gcd(F,R)=1 and f1 != 0. A selected cube root S of -F modulo R can be written S=u*(x+z), with u != 0. Put

    H0(z)=z^3-3s*z+r*s,
    H1(z)=3z^2-3r*z+r^2-s,
    G(z)=monic(f1*H0-f0*H1).

Every sheet choice occurs among the roots of G, up to multiplying S by a cube root of unity; this scalar does not affect the matrix rank below.

Modulo Q=R^9, the unique lift of S satisfying S_lift^3=-F is

    S_lift=S^25*(-F)^(-8).

This works since 25>=9 and (S^3+F)^25 is divisible by R^25. It applies equally to repeated R. Put U=F^(-8) mod Q and V=x^25*U mod Q. Apart from a nonzero scalar,

    S_lift=V+w*U,  where w=z^25.

The polynomial of w is obtained by raising every coefficient of G to the 25th power. The needed relation A-B*S_lift=0 mod R^9, with deg A<=6 and deg B<=2, forces the coefficients of x^7,x^8,x^9 in B*(V+wU) to vanish. The determinant of this 3 by 3 system is coprime to the polynomial of w in both candidate fields.

w2_exact.py prints the determinant and a Bezout identity alpha*det+beta*G_w=1 for each field. It checks the identity, not merely the outcome of a root search. Consequently all geometric sheet choices are excluded.

## Shared-fiber completeness reduction

After the degree-two result, an order-nine degree-three representative is finite and branch-free. A nontrivial representative with two distinct points in one fiber can be written P+rho(P)+Q with x(Q) different from x(P), and its class is [Q-rho^2(P)]. The supplied field bound and uniqueness of representatives force Q and rho^2(P) individually to be defined over F_(25^12).

A function with divisor 9Q-9R implies l(9R)>=2. At a nonbranch point the canonical basis is

    (1,x,...,x^5,y,xy,x^2*y) * dx/y^2.

With Hasse derivatives H_j, put

    D(x)=det( H_(6+i-j)(F^17)(x) )_(0<=i,j<=2).

The relevant local determinant differs from D(x) by a nonzero factor. weierstrass code verifies that D/F^33 is a nonzero polynomial of degree 161, then takes its monic normalization H. It computes the exact polynomial gcd

    gcd(H, x^(25^12)-x) = H9(x),

where

    H9(x)=x^6+(a+4)x^5+(3a+2)x^4+(2a+2)x^3+x^2+4a*x+(4a+4).

Irreducibility of H9 is verified. Its six roots and the three cube roots of F at each root give exactly 18 possible points, all in F_(25^6). The code verifies a cube root, rather than assuming its existence in that field. Frobenius and rho act transitively on these 18 points, so it suffices to fix one possible pole R.

At that R, the code verifies that l(9R)=2 and constructs a basis {1,h0}. It verifies the cancellations at the other two points in the x-fiber and the exact pole order 9 at R. The 15 candidates Q having a different x-coordinate are rho^j*pi^i(R), 1<=i<=5, 0<=j<=2. The derivative of h0 is nonzero at all 15. The product of the derivative numerators is printed and is nonzero in the verified degree-six field. Thus no member of the pencil can vanish to order 9 at one of those points.

Ordinary differentiation is used here only to prove NONvanishing of a derivative, which is a valid obstruction to a ninth-order zero in characteristic 5. All positive high-order vanishing conditions are handled by Hasse expansions or valuations.

## Files

- verify.py: driver, symbolic Cartier elimination, and irreducibility checks.
- ff25.py: elementary F_25 arithmetic and univariate polynomial arithmetic.
- w2_exact.py: extension arithmetic, ninth-order lift, matrix minors, and Bezout identities.
- w9_weierstrass.py: Hasse determinant and exact F_(25^12)-rationality gcd.
- shared_fiber_check.py: construction of L(9R) and all 15 derivative tests.
- *_certificate.json and weierstrass_data.json: generated exact coefficient data.

The remaining three-point case is not enumerated or certified by these files.
