"""Exact arithmetic certificate for the degree-two reduction. Field notation: a^2=a+3."""
from ff25 import ADD,NEG,MUL,INV,F,fmt,fmtp
from itertools import permutations

class Field:
 def __init__(self,modulus):
  assert modulus[-1]==1
  self.mod=list(modulus);self.d=len(modulus)-1
  self.zero=(0,)*self.d;self.one=(1,)+(0,)*(self.d-1)
 def const(self,x):return (x,)+(0,)*(self.d-1)
 def add(self,a,b):return tuple(ADD[u][v] for u,v in zip(a,b))
 def neg(self,a):return tuple(NEG[u] for u in a)
 def sub(self,a,b):return tuple(ADD[u][NEG[v]] for u,v in zip(a,b))
 def mul(self,a,b):
  d=self.d;c=[0]*(2*d-1)
  for i,u in enumerate(a):
   if u:
    for j,v in enumerate(b):
     if v:c[i+j]=ADD[c[i+j]][MUL[u][v]]
  for i in range(2*d-2,d-1,-1):
   v=c[i]
   if v:
    for j in range(d):c[i-d+j]=ADD[c[i-d+j]][NEG[MUL[v][self.mod[j]]]]
  return tuple(c[:d])
 def pow(self,a,n):
  r=self.one
  while n:
   if n&1:r=self.mul(r,a)
   a=self.mul(a,a);n>>=1
  return r
 def inv(self,a):
  assert a!=self.zero
  z=self.pow(a,25**self.d-2)
  assert self.mul(a,z)==self.one, ('not a field',self.mod,a)
  return z
 def div(self,a,b):return self.mul(a,self.inv(b))
 def eval(self,f,x):
  r=self.zero
  for c in f[::-1]:r=self.add(self.mul(r,x),self.const(c))
  return r
 def fmt(self,a):return '['+','.join(fmt(x) for x in a)+']'

class Poly:
 def __init__(self,K):self.K=K;self.z=K.zero;self.o=K.one
 def trim(self,a):
  a=list(a)
  while a and a[-1]==self.z:a.pop()
  return a
 def add(self,a,b):
  c=list(a)+[self.z]*max(0,len(b)-len(a))
  for i,v in enumerate(b):c[i]=self.K.add(c[i],v)
  return self.trim(c)
 def neg(self,a):return [self.K.neg(v) for v in a]
 def sub(self,a,b):return self.add(a,self.neg(b))
 def scale(self,a,c):return self.trim([self.K.mul(v,c) for v in a])
 def mul(self,a,b):
  if not a or not b:return []
  c=[self.z]*(len(a)+len(b)-1)
  for i,u in enumerate(a):
   for j,v in enumerate(b):c[i+j]=self.K.add(c[i+j],self.K.mul(u,v))
  return self.trim(c)
 def div(self,a,b):
  a=self.trim(a);b=self.trim(b);assert b
  q=[self.z]*max(0,len(a)-len(b)+1);iv=self.K.inv(b[-1])
  while len(a)>=len(b):
   i=len(a)-len(b);c=self.K.mul(a[-1],iv);q[i]=c
   a=self.sub(a,[self.z]*i+self.scale(b,c))
  return self.trim(q),a
 def mod(self,a,b):return self.div(a,b)[1]
 def monic(self,a):return self.scale(a,self.K.inv(a[-1])) if a else []
 def gcd(self,a,b):
  while b:a,b=b,self.mod(a,b)
  return self.monic(a)
 def xgcd(self,a,b):
  r0,r1=a,b;s0,s1=[self.o],[];t0,t1=[],[self.o]
  while r1:
   q,r=self.div(r0,r1)
   r0,r1=r1,r;s0,s1=s1,self.sub(s0,self.mul(q,s1));t0,t1=t1,self.sub(t0,self.mul(q,t1))
  iv=self.K.inv(r0[-1]);return self.scale(r0,iv),self.scale(s0,iv),self.scale(t0,iv)
 def inverse(self,a,m):
  g,s,t=self.xgcd(a,m);assert g==[self.o],('nonunit',g)
  return self.mod(s,m)
 def pow(self,a,n,m=None):
  r=[self.o]
  while n:
   if n&1:
    r=self.mul(r,a)
    if m:r=self.mod(r,m)
   a=self.mul(a,a)
   if m:a=self.mod(a,m)
   n>>=1
  return r
 def coeff(self,a,i):return a[i] if i<len(a) else self.z
 def fmt(self,a):return '['+', '.join(self.K.fmt(v) for v in a)+']'

def determinant3(p,rows):
 out=[]
 for perm in permutations(range(3)):
  sign=(-1)**sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
  term=[p.o]
  for i in range(3):term=p.mul(term,rows[i][perm[i]])
  out=p.add(out,term) if sign==1 else p.sub(out,term)
 return out

Sp=[15,15,18,2,4,5,15,10]
mods=[[13,1],[12,8,22,20,12,4,1]]

def run(modulus,verbose=True):
 K=Field(modulus);p=Poly(K);zero,one=K.zero,K.one
 r=K.const(NEG[modulus[0]]) if K.d==1 else (0,1)+(0,)*(K.d-2)
 s=K.eval(Sp,r)
 R=[s,r,one];FK=[K.const(c) for c in F]
 assert p.gcd(FK,R)==[one]
 FR=p.mod(FK,R);f0,f1=p.coeff(FR,0),p.coeff(FR,1)
 assert f1!=zero
 # z=v/u for a root S=u*x+v of -F modulo R.
 # (x+z)^3 mod R has coefficients H0(z),H1(z).
 H0=[K.mul(r,s),K.neg(K.mul(K.const(3),s)),zero,one]
 H1=[K.sub(K.mul(r,r),s),K.neg(K.mul(K.const(3),r)),K.const(3)]
 G=p.monic(p.sub(p.scale(H0,f1),p.scale(H1,f0)))
 Gw=[K.pow(c,25) for c in G]
 # S_lift/u^25=(x^25+z^25)*F^-8 mod R^9.
 Q=p.pow(R,9)
 U=p.pow(p.inverse(FK,Q),8,Q)
 V=p.mod([zero]*25+U,Q)
 shifts=[]
 for j in range(3):
  shifts.append((p.mod([zero]*j+V,Q),p.mod([zero]*j+U,Q)))
 from itertools import combinations
 attempts=0
 for ix in combinations(range(7,18),3):
  attempts+=1
  matrix=[[[p.coeff(shifts[j][0],i),p.coeff(shifts[j][1],i)] for j in range(3)] for i in ix]
  det=determinant3(p,matrix)
  gcd,alpha,beta=p.xgcd(det,Gw)
  if gcd==[one]:
   assert p.add(p.mul(alpha,det),p.mul(beta,Gw))==[one]
   if verbose:
    print('MODULUS',modulus,flush=True)
    print('r=',K.fmt(r),'s=',K.fmt(s),flush=True)
    print('discR=',K.fmt(K.sub(K.mul(r,r),K.mul(K.const(4),s))),flush=True)
    print('G_w=',p.fmt(Gw),flush=True)
    print('ROWS=',ix,'ATTEMPTS=',attempts,flush=True)
    print('DET=',p.fmt(det),flush=True)
    print('BEZOUT_ALPHA=',p.fmt(alpha),flush=True)
    print('BEZOUT_BETA=',p.fmt(beta),flush=True)
    print('CERTIFIED: rank=3 for every root of G_w.',flush=True)
   return dict(modulus=modulus,r=r,s=s,Gw=Gw,rows=ix,det=det,alpha=alpha,beta=beta)
 raise RuntimeError('No single minor is a unit; combine minors instead.')

if __name__=='__main__':
 import json
 data=[run(m) for m in mods]
 from pathlib import Path
 with open(Path(__file__).with_name('w2_certificate.json'),'w') as f:json.dump(data,f,indent=2)
