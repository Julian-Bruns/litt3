from w2_exact import Field, Poly
from ff25 import F,fmt
from math import comb
import json
H=[24,20,1,12,17,9,1]
K=Field(H);p=Poly(K);Z,O=K.zero,K.one
b=(0,1,0,0,0,0)
Fb=K.eval(F,b)
N=25**6-1;m=N//9
assert m%3
# Choose an element of order 9.
z9=None
for j in range(25):
 z=K.pow(K.add(b,K.const(j)),m)
 if K.pow(z,9)==O and K.pow(z,3)!=O:z9=z;break
assert z9 is not None
base=K.pow(Fb,pow(3,-1,m))
c=None
for j in range(9):
 y=K.mul(base,K.pow(z9,j))
 if K.pow(y,3)==Fb:c=y;break
assert c is not None
print('POINT b=r, c=',K.fmt(c),flush=True)
# Local y at R, with t=x-b. Hasse expansion to t^8.
Fshift=[]
for j in range(11):
 z=Z
 # Use the prime-field binomial coefficient times F_i.
 for i in range(j,11):
  z=K.add(z,K.mul(K.mul(K.const(F[i]),K.const(comb(i,j)%5)),K.pow(b,i-j)))
 Fshift.append(z)
modt9=[Z]*9+[O]
yseries=p.scale(p.pow(p.scale(Fshift,K.inv(Fb)),17,modt9),c)
M=[[p.coeff(yseries,i-j) for j in range(3)] for i in [6,7,8]]
# Gaussian elimination; output a basis of the right kernel.
def nullspace(M):
 A=[row[:] for row in M];piv=[];i=0
 for j in range(len(A[0])):
  k=next((k for k in range(i,len(A)) if A[k][j]!=Z),None)
  if k is None:continue
  A[i],A[k]=A[k],A[i];iv=K.inv(A[i][j]);A[i]=[K.mul(v,iv) for v in A[i]]
  for k in range(len(A)):
   if k!=i:
    cc=A[k][j];A[k]=[K.sub(A[k][l],K.mul(cc,A[i][l])) for l in range(len(A[0]))]
  piv.append(j);i+=1
  if i==len(A):break
 out=[]
 for j in range(len(A[0])):
  if j not in piv:
   v=[Z]*len(A[0]);v[j]=O
   for k,l in enumerate(piv):v[l]=K.neg(A[k][j])
   out.append(v)
 return out,piv,A
ker,piv,RR=nullspace(M)
print('rank',len(piv),'kernel dimension',len(ker),flush=True)
assert len(ker)==1
C=ker[0];assert C[0]!=Z
C=p.scale(C,K.inv(C[0]))
print('C(t)=',p.fmt(C),flush=True)
B=p.mul(C,yseries)[:6]
A=p.mul(C,p.pow(yseries,2,modt9))[:9]
# Verify imposed zeros at the other two points of the fiber.
zeta=K.const(11)
for j in [1,2]:
 ys=p.scale(yseries,K.pow(zeta,j))
 g=p.add(A,p.add(p.mul(B,ys),p.mul(C,p.pow(ys,2,modt9))))
 assert p.mod(g,modt9)==[]
# At R the numerator is nonzero, so h=g/t^9 has exact pole order 9.
assert K.add(A[0],K.add(K.mul(B[0],c),K.mul(C[0],K.pow(c,2))))!=Z

def derivative(f):return [K.mul(K.const(i%5),f[i]) for i in range(1,len(f))]
def ev(f,x):
 z=Z
 for v in f[::-1]:z=K.add(K.mul(z,x),v)
 return z
Ap,Bp,Cp=map(derivative,[A,B,C])
Fp=[(F[i]%5)*(i%5)%5+5*((F[i]//5)*(i%5)%5) for i in range(1,11)]
prod=O;checks=[]
for i in range(1,6):
 bx=K.pow(b,25**i);cy=K.pow(c,25**i);t=K.sub(bx,b)
 fx=K.eval(F,bx);fp=K.eval(Fp,bx)
 for j in range(3):
  y=K.mul(cy,K.pow(zeta,j));yy=K.mul(y,y)
  NN=K.add(ev(A,t),K.add(K.mul(ev(B,t),y),K.mul(ev(C,t),yy)))
  dd=K.add(ev(Ap,t),K.add(K.mul(ev(Bp,t),y),K.mul(ev(Cp,t),yy)))
  dd=K.add(K.mul(K.mul(K.const(3),fx),dd),K.mul(fp,K.add(K.mul(ev(B,t),y),K.mul(K.const(2),K.mul(ev(C,t),yy)))))
  E=K.sub(K.mul(t,dd),K.mul(K.mul(K.const(2),fx),NN))
  print('i,j',i,j,'derivative numerator=',K.fmt(E),flush=True)
  checks.append((i,j,E));prod=K.mul(prod,E)
print('PRODUCT',K.fmt(prod),flush=True)
assert prod!=Z
from pathlib import Path
with open(Path(__file__).with_name('shared_fiber_certificate.json'),'w') as f:json.dump({'H':H,'c':c,'C':C,'A':A,'B':B,'checks':checks,'product':prod},f,indent=2)
print('CERTIFIED: no distinct projected Weierstrass points have 9-torsion difference.',flush=True)
