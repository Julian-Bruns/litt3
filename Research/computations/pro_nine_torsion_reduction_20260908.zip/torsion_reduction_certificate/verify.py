#!/usr/bin/env python3
"""Run all exact certificates. Python 3, standard library only.

This verifies the NEW REDUCTION, not the original equality (*).
All calculations are in F_25 or in explicitly verified finite extension fields.
The geometric reductions proving that these finite calculations are complete
for their stated subcases are explained in README.md and the accompanying answer.
"""
from pathlib import Path
import runpy
from ff25 import *
BASE=Path(__file__).resolve().parent

def irreducible6(H):
 assert len(H)==7 and H[-1]==1
 x=[0,1]
 assert mod(ps(pp(x,25**6,H),x),H)==[]
 assert gcd(ps(pp(x,25**3,H),x),H)==[1]
 assert gcd(ps(pp(x,25**2,H),x),H)==[1]

# Check the base field table: a^2=a+3 and all nonzero elements invert.
assert mul(5,5)==8
for i in range(1,25):assert mul(i,INV[i])==1

# Symbolic bivariate polynomials in r,s, represented by dictionaries.
def da(A,B):
 C=dict(A)
 for m,c in B.items():C[m]=add(C.get(m,0),c)
 return {m:c for m,c in C.items() if c}
def dm(A,B):
 C={}
 for (i,j),c in A.items():
  for (k,l),d in B.items():
   m=(i+k,j+l);C[m]=add(C.get(m,0),mul(c,d))
 return {m:c for m,c in C.items() if c}
def ds(A,c):return {m:mul(v,c) for m,v in A.items() if mul(v,c)}
def dxmul(A,B):
 C=[{} for _ in range(len(A)+len(B)-1)]
 for i,a in enumerate(A):
  for j,b in enumerate(B):C[i+j]=da(C[i+j],dm(a,b))
 return C
r={(1,0):1};s={(0,1):1};one={(0,0):1}
R=[s,r,one];L=[da({(0,0):neg(F[9])},ds(r,neg(2))),one]
h=dxmul(dxmul(R,R),L);FH=dxmul([{(0,0):c} for c in F],h)
assert FH[14]=={}
# E4=a4*s^2+b4*s+c4, E9=a9*s^2+b9*s+c9.
a4,b4,c4=[11,22],[15,10,5],[24,6,17,24]
a9,b9,c9=[22,11],[14,3,9],[21,23,22,23]
def dict_from_s_coeff(coeffs):
 return {(i,j):c for j,P in enumerate(coeffs) for i,c in enumerate(P) if c}
assert FH[4]==dict_from_s_coeff([c4,b4,a4])
assert FH[9]==dict_from_s_coeff([c9,b9,a9])
# Quadratic resultant in s, with the standard explicit formula.
AFCD=ps(pm(a4,c9),pm(c4,a9))
AEBD=ps(pm(a4,b9),pm(b4,a9))
BFCE=ps(pm(b4,c9),pm(c4,b9))
resultant=ps(pm(AFCD,AFCD),pm(AEBD,BFCE))
P=[8,17,21,10,3,5,22,20,1]
assert resultant==scale(P,17)  # 17 encodes 3a+2.
linL=ps(pm(a9,b4),pm(a4,b9));linM=ps(pm(a9,c4),pm(a4,c9))
assert linL==[20,12,23,6] and linM==[6,20,22,17,24]
assert gcd(linL,P)==[1]
Sp=[15,15,18,2,4,5,15,10]
assert mod(pa(pm(linL,Sp),linM),P)==[]
H2=[12,8,22,20,12,4,1]
assert P==pm(pm([13,1],[13,1]),H2)
irreducible6(H2)
H9=[24,20,1,12,17,9,1]
irreducible6(H9)
print('PASS: symbolic Cartier equations, resultant, linear recovery of s, and field certificates.',flush=True)

print('\n=== DEGREE-TWO NINTH-ORDER TESTS ===',flush=True)
runpy.run_path(str(BASE/'w2_exact.py'),run_name='__main__')
print('\n=== RATIONAL WEIERSTRASS ABSCISSAS ===',flush=True)
runpy.run_path(str(BASE/'w9_weierstrass.py'),run_name='__main__')
print('\n=== SHARED-FIBER DEGREE-THREE TESTS ===',flush=True)
runpy.run_path(str(BASE/'shared_fiber_check.py'),run_name='__main__')
print('\nALL CERTIFICATES PASS.',flush=True)
print('These computations exclude degree-two order-nine classes and the shared-fiber degree-three case.',flush=True)
print('They do NOT settle degree-three divisors with branch-free support and distinct support abscissas.',flush=True)
