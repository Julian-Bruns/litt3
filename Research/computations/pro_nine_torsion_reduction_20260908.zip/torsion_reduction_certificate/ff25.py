p=5
q=25
ADD=[[((i%5+j%5)%5)+5*((i//5+j//5)%5) for j in range(25)] for i in range(25)]
NEG=[((-i%5)%5)+5*((-(i//5))%5) for i in range(25)]
MUL=[]
for i in range(25):
 r=[]
 u,v=i%5,i//5
 for j in range(25):
  z,w=j%5,j//5
  r.append((u*z+3*v*w)%5+5*((u*w+v*z+v*w)%5))
 MUL.append(r)
def add(a,b):return ADD[a][b]
def neg(a):return NEG[a]
def sub(a,b):return ADD[a][NEG[b]]
def mul(a,b):return MUL[a][b]
def power(a,n):
 r=1
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n>>=1
 return r
INV=[0]+[power(i,23) for i in range(1,25)]
def div(a,b):
 assert b
 return mul(a,INV[b])
def trim(a):
 a=list(a)
 while a and not a[-1]:a.pop()
 return a
def pa(a,b):
 c=list(a)+[0]*max(0,len(b)-len(a))
 for i,x in enumerate(b):c[i]=add(c[i],x)
 return trim(c)
def pn(a):return [neg(x) for x in a]
def ps(a,b):return pa(a,pn(b))
def scale(a,c):return trim([mul(x,c) for x in a])
def pm(a,b):
 if not a or not b:return []
 c=[0]*(len(a)+len(b)-1)
 for i,u in enumerate(a):
  for j,v in enumerate(b):c[i+j]=add(c[i+j],mul(u,v))
 return trim(c)
def pd(a,b):
 a=trim(a);b=trim(b)
 assert b
 qq=[0]*max(0,len(a)-len(b)+1)
 while len(a)>=len(b):
  i=len(a)-len(b);c=div(a[-1],b[-1]);qq[i]=c
  a=ps(a,[0]*i+scale(b,c))
 return trim(qq),a
def mod(a,b):return pd(a,b)[1]
def monic(a):return scale(a,INV[a[-1]]) if a else []
def gcd(a,b):
 while b:a,b=b,mod(a,b)
 return monic(a)
def pp(a,n,f=None):
 r=[1]
 while n:
  if n&1:
   r=pm(r,a)
   if f:r=mod(r,f)
  a=pm(a,a)
  if f:a=mod(a,f)
  n>>=1
 return r
def val(f,x):
 r=0
 for c in f[::-1]:r=add(mul(r,x),c)
 return r
def fmt(c):
 b,a=c%5,c//5
 return str(b) if a==0 else (('a' if a==1 else str(a)+'a')+('+'+str(b) if b else ''))
def fmtp(f):return ' + '.join(fmt(c)+('x^'+str(i) if i else '') for i,c in enumerate(f) if c) or '0'
F=[11,22,18,5,19,20,15,16,9,22,1]
if __name__=='__main__':
 print('F',fmtp(F));print('zeta',[fmt(i) for i in range(2,25) if power(i,3)==1])
 print('roots', [fmt(x) for x in range(25) if val(F,x)==0])
 for d in [1,2,4]:
  h=gcd(ps(pp([0,1],25**d,F),[0,1]),F)
  print('degree divides',d,fmtp(h))

def factor(f):
 import random
 random.seed(173)
 f=monic(f)
 out=[]
 def split(g,d):
  if len(g)-1==d:return [g]
  while True:
   a=trim([random.randrange(25) for _ in range(len(g)-1)])
   b=gcd(ps(pp(a,(25**d-1)//2,g),[1]),g)
   if len(b)>1 and len(b)<len(g):return split(b,d)+split(pd(g,b)[0],d)
 d=1
 while len(f)>1:
  h=gcd(ps(pp([0,1],25**d,f),[0,1]),f)
  if len(h)>1:
   out.extend(split(h,d));f=pd(f,h)[0]
  d+=1
  if d>20:raise ValueError('not squarefree?')
 return out
