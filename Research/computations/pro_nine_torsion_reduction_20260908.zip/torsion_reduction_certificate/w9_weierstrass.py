from ff25 import *
from math import comb
from itertools import permutations
import json,time
P=pp(F,17)
h={j:[mul(c,comb(i,j)%5) for i,c in enumerate(P) if i>=j] for j in range(4,9)}
H=[]
for sig in permutations(range(3)):
 v=[1]
 for i in range(3):v=pm(v,h[6+i-sig[i]])
 parity=sum(sig[i]>sig[j] for i in range(3) for j in range(i+1,3))%2
 H=ps(H,v) if parity else pa(H,v)
H=trim(H)
e=0
while H:
 q,r=pd(H,F)
 if r:break
 H=q;e+=1
print('F power removed',e,'remainingdegree',len(H)-1,flush=True)
H=monic(H)
hh=gcd(ps(pp([0,1],25**12,H),[0,1]),H)
print('RATIONAL WEIERSTRASS ABSCISSA POLYNOMIAL: degree',len(hh)-1,'coefficients',hh,flush=True)
assert hh == [24,20,1,12,17,9,1]
assert e == 33 and len(H)-1 == 161
print('CERTIFIED: exactly the six roots of the displayed polynomial can occur.',flush=True)
from pathlib import Path
with open(Path(__file__).with_name('weierstrass_data.json'),'w') as f:json.dump({'H':H,'rational':hh},f,indent=2)
